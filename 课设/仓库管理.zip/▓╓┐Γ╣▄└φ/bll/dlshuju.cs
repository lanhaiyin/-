﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace bll
{
    public class dlshuju
    {
        public static string dlzh;
        public static string dlmm;
        public static int qx;
        public static Form fr;
        public static Form fr2;
    }
}
