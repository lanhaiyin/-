﻿namespace 仓库管理
{
    partial class zhuye
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.账户管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.入库管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品录入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品修改与删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.入库添加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.入库验证ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.出库管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.出库添加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.出库检阅ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.查询货物ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品库存ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.订单号ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.出库号ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.日期查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.货架情况ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.货架管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.货架输入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.货架修改删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.账户管理ToolStripMenuItem,
            this.入库管理ToolStripMenuItem,
            this.出库管理ToolStripMenuItem,
            this.查询货物ToolStripMenuItem,
            this.货架管理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1184, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 账户管理ToolStripMenuItem
            // 
            this.账户管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加用户ToolStripMenuItem,
            this.修改用户ToolStripMenuItem,
            this.删除用户ToolStripMenuItem,
            this.修改密码ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.账户管理ToolStripMenuItem.Name = "账户管理ToolStripMenuItem";
            this.账户管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.账户管理ToolStripMenuItem.Text = "账户管理";
            // 
            // 添加用户ToolStripMenuItem
            // 
            this.添加用户ToolStripMenuItem.Name = "添加用户ToolStripMenuItem";
            this.添加用户ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.添加用户ToolStripMenuItem.Text = "添加用户";
            this.添加用户ToolStripMenuItem.Click += new System.EventHandler(this.添加用户ToolStripMenuItem_Click);
            // 
            // 修改用户ToolStripMenuItem
            // 
            this.修改用户ToolStripMenuItem.Name = "修改用户ToolStripMenuItem";
            this.修改用户ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.修改用户ToolStripMenuItem.Text = "修改用户";
            this.修改用户ToolStripMenuItem.Click += new System.EventHandler(this.修改用户ToolStripMenuItem_Click);
            // 
            // 删除用户ToolStripMenuItem
            // 
            this.删除用户ToolStripMenuItem.Name = "删除用户ToolStripMenuItem";
            this.删除用户ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.删除用户ToolStripMenuItem.Text = "删除用户";
            this.删除用户ToolStripMenuItem.Click += new System.EventHandler(this.删除用户ToolStripMenuItem_Click);
            // 
            // 修改密码ToolStripMenuItem
            // 
            this.修改密码ToolStripMenuItem.Name = "修改密码ToolStripMenuItem";
            this.修改密码ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.修改密码ToolStripMenuItem.Text = "修改密码";
            this.修改密码ToolStripMenuItem.Click += new System.EventHandler(this.修改密码ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // 入库管理ToolStripMenuItem
            // 
            this.入库管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.商品录入ToolStripMenuItem,
            this.商品修改与删除ToolStripMenuItem,
            this.入库添加ToolStripMenuItem,
            this.入库验证ToolStripMenuItem});
            this.入库管理ToolStripMenuItem.Name = "入库管理ToolStripMenuItem";
            this.入库管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.入库管理ToolStripMenuItem.Text = "入库管理";
            // 
            // 商品录入ToolStripMenuItem
            // 
            this.商品录入ToolStripMenuItem.Name = "商品录入ToolStripMenuItem";
            this.商品录入ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.商品录入ToolStripMenuItem.Text = "商品录入";
            this.商品录入ToolStripMenuItem.Click += new System.EventHandler(this.商品录入ToolStripMenuItem_Click);
            // 
            // 商品修改与删除ToolStripMenuItem
            // 
            this.商品修改与删除ToolStripMenuItem.Name = "商品修改与删除ToolStripMenuItem";
            this.商品修改与删除ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.商品修改与删除ToolStripMenuItem.Text = "商品修改与删除";
            this.商品修改与删除ToolStripMenuItem.Click += new System.EventHandler(this.商品修改与删除ToolStripMenuItem_Click);
            // 
            // 入库添加ToolStripMenuItem
            // 
            this.入库添加ToolStripMenuItem.Name = "入库添加ToolStripMenuItem";
            this.入库添加ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.入库添加ToolStripMenuItem.Text = "入库添加";
            this.入库添加ToolStripMenuItem.Click += new System.EventHandler(this.入库添加ToolStripMenuItem_Click);
            // 
            // 入库验证ToolStripMenuItem
            // 
            this.入库验证ToolStripMenuItem.Name = "入库验证ToolStripMenuItem";
            this.入库验证ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.入库验证ToolStripMenuItem.Text = "入库验证";
            this.入库验证ToolStripMenuItem.Click += new System.EventHandler(this.入库验证ToolStripMenuItem_Click);
            // 
            // 出库管理ToolStripMenuItem
            // 
            this.出库管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.出库添加ToolStripMenuItem,
            this.出库检阅ToolStripMenuItem1});
            this.出库管理ToolStripMenuItem.Name = "出库管理ToolStripMenuItem";
            this.出库管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.出库管理ToolStripMenuItem.Text = "出库管理";
            // 
            // 出库添加ToolStripMenuItem
            // 
            this.出库添加ToolStripMenuItem.Name = "出库添加ToolStripMenuItem";
            this.出库添加ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.出库添加ToolStripMenuItem.Text = "出库添加";
            this.出库添加ToolStripMenuItem.Click += new System.EventHandler(this.出库添加ToolStripMenuItem_Click);
            // 
            // 出库检阅ToolStripMenuItem1
            // 
            this.出库检阅ToolStripMenuItem1.Name = "出库检阅ToolStripMenuItem1";
            this.出库检阅ToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.出库检阅ToolStripMenuItem1.Text = "出库检阅";
            this.出库检阅ToolStripMenuItem1.Click += new System.EventHandler(this.出库检阅ToolStripMenuItem1_Click);
            // 
            // 查询货物ToolStripMenuItem
            // 
            this.查询货物ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.商品库存ToolStripMenuItem,
            this.订单号ToolStripMenuItem,
            this.出库号ToolStripMenuItem,
            this.日期查询ToolStripMenuItem,
            this.货架情况ToolStripMenuItem});
            this.查询货物ToolStripMenuItem.Name = "查询货物ToolStripMenuItem";
            this.查询货物ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.查询货物ToolStripMenuItem.Text = "查询货物";
            // 
            // 商品库存ToolStripMenuItem
            // 
            this.商品库存ToolStripMenuItem.Name = "商品库存ToolStripMenuItem";
            this.商品库存ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.商品库存ToolStripMenuItem.Text = "商品库存";
            this.商品库存ToolStripMenuItem.Click += new System.EventHandler(this.商品库存ToolStripMenuItem_Click);
            // 
            // 订单号ToolStripMenuItem
            // 
            this.订单号ToolStripMenuItem.Name = "订单号ToolStripMenuItem";
            this.订单号ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.订单号ToolStripMenuItem.Text = "入库号查询";
            this.订单号ToolStripMenuItem.Click += new System.EventHandler(this.订单号ToolStripMenuItem_Click);
            // 
            // 出库号ToolStripMenuItem
            // 
            this.出库号ToolStripMenuItem.Name = "出库号ToolStripMenuItem";
            this.出库号ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.出库号ToolStripMenuItem.Text = "出库号查询";
            this.出库号ToolStripMenuItem.Click += new System.EventHandler(this.出库号ToolStripMenuItem_Click);
            // 
            // 日期查询ToolStripMenuItem
            // 
            this.日期查询ToolStripMenuItem.Name = "日期查询ToolStripMenuItem";
            this.日期查询ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.日期查询ToolStripMenuItem.Text = "日期查询";
            this.日期查询ToolStripMenuItem.Click += new System.EventHandler(this.日期查询ToolStripMenuItem_Click);
            // 
            // 货架情况ToolStripMenuItem
            // 
            this.货架情况ToolStripMenuItem.Name = "货架情况ToolStripMenuItem";
            this.货架情况ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.货架情况ToolStripMenuItem.Text = "货架情况";
            this.货架情况ToolStripMenuItem.Click += new System.EventHandler(this.货架情况ToolStripMenuItem_Click);
            // 
            // 货架管理ToolStripMenuItem
            // 
            this.货架管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.货架输入ToolStripMenuItem,
            this.货架修改删除ToolStripMenuItem});
            this.货架管理ToolStripMenuItem.Name = "货架管理ToolStripMenuItem";
            this.货架管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.货架管理ToolStripMenuItem.Text = "货架管理";
            // 
            // 货架输入ToolStripMenuItem
            // 
            this.货架输入ToolStripMenuItem.Name = "货架输入ToolStripMenuItem";
            this.货架输入ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.货架输入ToolStripMenuItem.Text = "货架输入";
            this.货架输入ToolStripMenuItem.Click += new System.EventHandler(this.货架输入ToolStripMenuItem_Click);
            // 
            // 货架修改删除ToolStripMenuItem
            // 
            this.货架修改删除ToolStripMenuItem.Name = "货架修改删除ToolStripMenuItem";
            this.货架修改删除ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.货架修改删除ToolStripMenuItem.Text = "货架修改删除";
            this.货架修改删除ToolStripMenuItem.Click += new System.EventHandler(this.货架修改删除ToolStripMenuItem_Click);
            // 
            // zhuye
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 612);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "zhuye";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "仓库管理系统";
            this.Load += new System.EventHandler(this.zhuye_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 账户管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改密码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 入库管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 入库添加ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 入库验证ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 出库管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 出库添加ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 出库检阅ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 查询货物ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品库存ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 订单号ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 出库号ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 日期查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 货架情况ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 货架管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品录入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品修改与删除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 货架输入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 货架修改删除ToolStripMenuItem;
    }
}