﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace model
{
    public class dl
    {
        string inzh;
        string inmm;
        string inxm;
        int inqx;
        public string zh
        {
            get { return inzh; }
            set { inzh = value; }
        }
        public string mm
        {
            get { return inmm; }
            set { inmm = value; }
        }
        public string xm
        {
            get { return inxm; }
            set { inxm = value; }
        }
        public int qx
        {
            get { return inqx; }
            set { inqx = value; }
        }
    }
}
