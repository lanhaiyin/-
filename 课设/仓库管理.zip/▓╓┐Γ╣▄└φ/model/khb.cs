﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace model
{
    public class khb
    {
        private int intkhbh;
        private string strkh;
        private string strkhdh;

        public int khbh
        {
            get { return intkhbh; }
            set { intkhbh = value; }
        }
        public string kh
        {
            get { return strkh; }
            set { strkh = value; }
        }
        public string khdh
        {
            get { return strkhdh; }
            set { strkhdh = value; }
        }
    }
}
