﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace model
{
    public class mm
    {
        string inymm;
        string inxmm;
        string inqrxmm;
        public string ymm
        {
            get { return inymm; }
            set { inymm = value; }
        }
        public string xmm
        {
            get { return inxmm; }
            set { inxmm = value; }
        }
    }
}
