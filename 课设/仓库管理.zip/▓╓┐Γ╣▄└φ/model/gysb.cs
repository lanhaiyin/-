﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace model
{
    public class gysb
    {
        private int intgysbh;
        private string strgys;
        private string strgysdh;

        public int gysbh
        {
            get { return intgysbh; }
            set { intgysbh = value; }
        }
        public string gys
        {
            get { return strgys; }
            set { strgys = value; }
        }
        public string gysdh
        {
            get { return gysdh; }
            set { gysdh = value; }
        }
    }
}
