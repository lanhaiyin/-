﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace model
{
    public class rkb
    {
        private int intrkbh;
        private int strspbh;
        private string strxh;
        private int intsl;
        private string strrkr;
        private int intgysbh;
        private string strcfhj;
        private DateTime dtmrksj;
        private int intyz;
        private string strspm;
        private string strgys;


        public int rkbh
        {
            get { return intrkbh; }
            set { intrkbh = value; }
        }
        public string gys
        {
            get { return strgys; }
            set { strgys = value; }
        }
        public string spm
        {
            get { return strspm; }
            set { strspm = value; }
        }
        public int spbh
        {
            get { return strspbh; }
            set { strspbh = value; }
        }
        public string xh
        {
            get { return strxh; }
            set { strxh = value; }
        }
        public int sl
        {
            get { return intsl; }
            set { intsl = value; }
        }
        public string rkr
        {
            get { return strrkr; }
            set { strrkr = value; }
        }
        public int gysbh
        {
            get { return intgysbh; }
            set { intgysbh = value; }
        }
        public string cfhj
        {
            get { return strcfhj; }
            set { strcfhj = value; }
        }
        public DateTime rksj
        {
            get { return dtmrksj; }
            set { dtmrksj = value; }
        }
        public int yz
        {
            get { return intyz; }
            set { intyz = value; }
        }
    }
}
