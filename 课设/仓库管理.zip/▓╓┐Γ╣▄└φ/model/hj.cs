﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace model
{
    public class hj
    {
        private string inhjbh;
        private string inhjck;
        public string hjbh
        {
            get { return inhjbh; }
            set { inhjbh = value; }
        }
        public string hjck
        {
            get { return inhjck; }
            set { inhjck = value; }
        }
    }
}
